import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adm-cont',
  templateUrl: './adm-cont.component.html',
  styleUrls: ['./adm-cont.component.css']
})
export class AdmContComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
