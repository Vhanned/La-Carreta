import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'menuprincipal',
  templateUrl: './menuprincipal.component.html',
  styleUrls: ['./menuprincipal.component.css']
})
export class MenuprincipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
