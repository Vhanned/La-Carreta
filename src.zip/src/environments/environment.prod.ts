export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB5ZeYazet5e0QFO8bsLlopDX63BcBn3qk",
    authDomain: "cheesetrack-dd8bc.firebaseapp.com",
    projectId: "cheesetrack-dd8bc",
    storageBucket: "cheesetrack-dd8bc.appspot.com",
    messagingSenderId: "255709776623",
    appId: "1:255709776623:web:f022f32d6c0903cf66e91a",
    measurementId: "G-R7V8XREJT9"
  }
};
